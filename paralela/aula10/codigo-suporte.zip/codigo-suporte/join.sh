#!/bin/bash -xe

benchmark=vectoradd
PREFIX_BENCHMARK=omp
EXPERIMENT=schedule-test

echo "Executing test for $benchmark, start at `date +'%d/%m/%Y-%T'`"

if [ -e *-final.csv ]
then
    rm *-final.csv
fi

for size_of_data in 1048576; do
	for num_threads in 1 2 4 8; do
		for omp_schedule in STATIC DYNAMIC GUIDED RUNTIME; do
			for chunk_size in 16 32 64 128 256; do
				echo "Compiling ${benchmark} with dataset: ${size_of_data}, schedule: ${omp_schedule}, chunk: ${chunk_size}, threads: ${num_threads}."
				python csvize-experiments-results.py -i data-${benchmark}-dataset-${size_of_data}-schedule-${omp_schedule}-chunk-${chunk_size}-threads-${num_threads}-${PREFIX_BENCHMARK}.csv -o data-${benchmark}-dataset-${size_of_data}-schedule-${omp_schedule}-chunk-${chunk_size}-threads-${num_threads}-${PREFIX_BENCHMARK}-tratado.csv

				header=`head -n 1 data-${benchmark}-dataset-${size_of_data}-schedule-${omp_schedule}-chunk-${chunk_size}-threads-${num_threads}-${PREFIX_BENCHMARK}-tratado.csv`
				num_lines=`cat data-${benchmark}-dataset-${size_of_data}-schedule-${omp_schedule}-chunk-${chunk_size}-threads-${num_threads}-${PREFIX_BENCHMARK}-tratado.csv | wc -l` 
				((num_lines=num_lines-1))

				tail -n ${num_lines} data-${benchmark}-dataset-${size_of_data}-schedule-${omp_schedule}-chunk-${chunk_size}-threads-${num_threads}-${PREFIX_BENCHMARK}-tratado.csv >> temp.csv
			done
		done
	done
done
echo ${header} > ${EXPERIMENT}-${benchmark}-${PREFIX_BENCHMARK}-joined-processed-final.csv
cat temp.csv >> ${EXPERIMENT}-${benchmark}-${PREFIX_BENCHMARK}-joined-processed-final.csv
echo "End of tests at `date +'%d/%m/%Y-%T'`"
