#include <stdio.h>
#include <stdlib.h>
#include "macros.h"
#include "timing.h"

// Size of vectors.
#ifndef N
#define N 1048576
#endif
// Entrada e sa�da.
float h_a[N];
float h_b[N];
float h_c[N];

void init_array() {
  // fprintf(stdout, "Inicializando os arrays.\n");
  int i;
  // Initialize vectors on host.
	for (i = 0; i < N; i++) {
	  h_a[i] = 0.5;
	  h_b[i] = 0.5;
	}
}

void print_array() {
  int i;
  for (i = 0; i < N; i++) {
	fprintf(stdout, "h_c[%07d]: %f\n", i, h_c[i]);
  }
}

void check_result(){
  // Soma dos elementos do array C e divide por N, o valor deve ser igual a 1.
  int i;
  float sum = 0;
  fprintf(stdout, "Verificando o resultado.\n");  
  
  for (i = 0; i < N; i++) {
	  sum += h_c[i];
	}
	
	fprintf(stdout, "Resultado Final: (%f, %f)\n", sum, (float)(sum / (float)N));
}

int main(int argc, char **argv) {
  int i;
  /* Inicializa��o  dos vetores. */
  init_array();
  
	/* C�lculo. */
  HOOKOMP_TIMING_OMP_START;
  #pragma omp parallel num_threads(OPENMP_NUM_THREADS)
  {
    #pragma omp for schedule(OPENMP_SCHEDULE_WITH_CHUNK)
    for (i = 0; i < N; i++) {
      h_c[i] = h_a[i] + h_b[i];
    }
  }
  HOOKOMP_TIMING_OMP_STOP;

  fprintf(stdout, "version = OMP, num_threads = %d, N = %d, ", OPENMP_NUM_THREADS, N);
  HOOKOMP_PRINT_TIME_RESULTS;
  
  /* Resultados. */
	// print_array();
	// check_result();
  
  return 0;
}
